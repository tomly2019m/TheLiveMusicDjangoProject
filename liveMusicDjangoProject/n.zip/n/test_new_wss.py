import json
import time

import utils

import struct
import zlib
import asyncio
import websockets


class Proto:
    def __init__(self):
        self.packetLen = 0
        self.headerLen = 16
        self.ver = 0
        self.op = 0
        self.seq = 0
        self.body = ''
        self.maxBody = 2048

    def pack(self):
        self.packetLen = len(self.body) + self.headerLen
        buf = struct.pack('>i', self.packetLen)
        buf += struct.pack('>h', self.headerLen)
        buf += struct.pack('>h', self.ver)
        buf += struct.pack('>i', self.op)
        buf += struct.pack('>i', self.seq)
        buf += self.body.encode()
        return buf

    def unpack(self, buf):
        if len(buf) < self.headerLen:
            print("包头不够")
            return
        self.packetLen = struct.unpack('>i', buf[0:4])[0]
        self.headerLen = struct.unpack('>h', buf[4:6])[0]
        self.ver = struct.unpack('>h', buf[6:8])[0]
        self.op = struct.unpack('>i', buf[8:12])[0]
        self.seq = struct.unpack('>i', buf[12:16])[0]
        if self.packetLen < 0 or self.packetLen > self.maxBody:
            print("包体长不对", "self.packetLen:", self.packetLen,
                  " self.maxBody:", self.maxBody)
            return
        if self.headerLen != self.headerLen:
            print("包头长度不对")
            return
        bodyLen = self.packetLen - self.headerLen
        self.body = buf[16:self.packetLen]
        if bodyLen <= 0:
            return
        if self.ver == 0:
            # 这里做回调
            print("====> callback:", self.body.decode('utf-8'))
        elif self.ver == 2:
            # 解压
            self.body = zlib.decompress(self.body)
            bodyLen = len(self.body)
            offset = 0
            while offset < bodyLen:
                cmdSize = struct.unpack('>i', self.body[offset:offset + 4])[0]
                if offset + cmdSize > bodyLen:
                    return
                newProto = Proto()
                newProto.unpack(self.body[offset: offset + cmdSize])
                offset += cmdSize
        else:
            return


# https://play-live.bilibili.com/plugins-full/1649539569084?Timestamp=1654437988&RoomId=24701480&Mid=29418115&Caller=bilibili&Sign=aefb0d56cbd3a2c97e8d95f6cd4b6acc4ba448025804824b97076c165b90805a&Code=BLMNUWXVJWU85&CodeSign=8dcd713664443a8a59061c14826d0620f48bb19dc66c0d95aa0211e97cd40662&plug_env=0
content = utils.get_websocket_info(code='BLMNUWXVJWU85', app_id=1649539569084)['content']

game_id = content['data']['game_info']['game_id']

wss_links = content['data']['websocket_info']['wss_link']

print(game_id)
print(wss_links)
print(content['data']['websocket_info']['auth_body'])


# async def hello():
#     p = Proto()
#     p.op = 7
#     p.body = content['data']['websocket_info']['auth_body']
#     p_pack = p.pack()
#     async with websockets.connect(wss_links[1]) as websocket:
#
#         await websocket.send(p_pack)
#         print(f"> {p_pack}")
#         print(f"> {p.unpack(p_pack)}")
#
#         greeting = await websocket.recv()
#         print(f"< {p.unpack(greeting)}")
#
#         greeting = await websocket.recv()
#         print(f"< {p.unpack(greeting)}")
#
#         greeting = await websocket.recv()
#         print(f"< {p.unpack(greeting)}")
#
#     print('done')
#     # while (True):
#     #     time.sleep(19)
#     #     utils.send_batch_heartbeat(game_ids=[game_id])
#
# asyncio.get_event_loop().run_until_complete(hello())



