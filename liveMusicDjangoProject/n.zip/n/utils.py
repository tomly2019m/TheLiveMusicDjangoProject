import re
import time
import json
import hmac
import atexit
import hashlib
import pymysql
import kuWoApi
import datetime
import requests
import bili_auth
import qqMusicApi
import cloudMusicApi

try:
    import django
    try:
        from TestModel.models import UsersData, UsersInfo
        from liveMusicDjangoProject.n import main_class
    except django.core.exceptions.ImproperlyConfigured:
        print('数据库配置文件有误')
except (AttributeError, ModuleNotFoundError):
    print('模块缺失，未导入数据库')

test_dan = [{'text': '点歌 百变奶精&Hanser', 'dm_type': 0, 'uid': 29418115, 'nickname': '虫草小王子', 'uname_color': '#00D1F1',
             'timeline': '2022-02-09 22:58:41', 'isadmin': 0, 'vip': 0, 'svip': 0,
             'medal': [11, '秋林喵', '秋林音食Akibaya', 630141, 6126494, '', 0, 6126494, 6126494, 6126494, 0, 1, 8100585],
             'title': ['', ''], 'user_level': [10, 0, 6406234, '>50000'], 'rank': 10000, 'teamid': 0,
             'rnd': '1322379141', 'user_title': '', 'guard_level': 3, 'bubble': 5,
             'bubble_color': '#1453BAFF,#4C2263A2,#3353BAFF', 'lpl': 0,
             'check_info': {'ts': 1634301097, 'ct': '61C98065'},
             'voice_dm_info': {'voice_url': '', 'file_format': '', 'text': '', 'file_duration': 0, 'file_id': ''},
             'emoticon': {'id': 0, 'emoticon_unique': '', 'text': '', 'perm': 0, 'url': '', 'in_player_area': 0,
                          'bulge_display': 0, 'is_dynamic': 0, 'height': 0, 'width': 0}},
            {'text': '点歌 フリージア&Uru', 'dm_type': 0, 'uid': 8100585, 'nickname': '秋林音食Akibaya', 'uname_color': '',
             'timeline': '2022-03-15 22:05:39', 'isadmin': 0, 'vip': 0, 'svip': 0, 'medal': [], 'title': ['', ''],
             'user_level': [13, 0, 6406234, '>50000'], 'rank': 10000, 'teamid': 0, 'rnd': '2090858909',
             'user_title': '', 'guard_level': 0, 'bubble': 0, 'bubble_color': '', 'lpl': 0, 'yeah_space_url': '',
             'jump_to_url': '', 'check_info': {'ts': 1647353139, 'ct': 'E9E42F9B'},
             'voice_dm_info': {'voice_url': '', 'file_format': '', 'text': '', 'file_duration': 0, 'file_id': ''},
             'emoticon': {'id': 0, 'emoticon_unique': '', 'text': '', 'perm': 0, 'url': '', 'in_player_area': 0,
                          'bulge_display': 0, 'is_dynamic': 0, 'height': 0, 'width': 0}},
            {'text': '点歌 的&url', 'dm_type': 0, 'uid': 29418115, 'nickname': '虫草小王子', 'uname_color': '#00D1F1',
             'timeline': '2022-02-09 22:58:41', 'isadmin': 0, 'vip': 0, 'svip': 0,
             'medal': [11, '秋林喵', '秋林音食Akibaya', 630141, 6126494, '', 0, 6126494, 6126494, 6126494, 0, 1, 8100585],
             'title': ['', ''], 'user_level': [10, 0, 6406234, '>50000'], 'rank': 10000, 'teamid': 0,
             'rnd': '1322379141', 'user_title': '', 'guard_level': 3, 'bubble': 5,
             'bubble_color': '#1453BAFF,#4C2263A2,#3353BAFF', 'lpl': 0,
             'check_info': {'ts': 1634301097, 'ct': '61C98065'},
             'voice_dm_info': {'voice_url': '', 'file_format': '', 'text': '', 'file_duration': 0, 'file_id': ''},
             'emoticon': {'id': 0, 'emoticon_unique': '', 'text': '', 'perm': 0, 'url': '', 'in_player_area': 0,
                          'bulge_display': 0, 'is_dynamic': 0, 'height': 0, 'width': 0}},
            {'text': '点歌 群青', 'dm_type': 0, 'uid': 29418115, 'nickname': '虫草小王子', 'uname_color': '#00D1F1',
             'timeline': '2022-02-09 22:58:41', 'isadmin': 0, 'vip': 0, 'svip': 0,
             'medal': [11, '秋林喵', '秋林音食Akibaya', 630141, 6126494, '', 0, 6126494, 6126494, 6126494, 0, 1, 8100585],
             'title': ['', ''], 'user_level': [10, 0, 6406234, '>50000'], 'rank': 10000, 'teamid': 0,
             'rnd': '1322379141', 'user_title': '', 'guard_level': 3, 'bubble': 5,
             'bubble_color': '#1453BAFF,#4C2263A2,#3353BAFF', 'lpl': 0,
             'check_info': {'ts': 1634301097, 'ct': '61C98065'},
             'voice_dm_info': {'voice_url': '', 'file_format': '', 'text': '', 'file_duration': 0, 'file_id': ''},
             'emoticon': {'id': 0, 'emoticon_unique': '', 'text': '', 'perm': 0, 'url': '', 'in_player_area': 0,
                          'bulge_display': 0, 'is_dynamic': 0, 'height': 0, 'width': 0}},
            {'text': '点歌 恋&星野源', 'dm_type': 0, 'uid': 29418115, 'nickname': '虫草小王子', 'uname_color': '#00D1F1',
             'timeline': '2022-02-09 22:58:41', 'isadmin': 0, 'vip': 0, 'svip': 0,
             'medal': [11, '秋林喵', '秋林音食Akibaya', 630141, 6126494, '', 0, 6126494, 6126494, 6126494, 0, 1, 8100585],
             'title': ['', ''], 'user_level': [10, 0, 6406234, '>50000'], 'rank': 10000, 'teamid': 0,
             'rnd': '1322379141', 'user_title': '', 'guard_level': 3, 'bubble': 5,
             'bubble_color': '#1453BAFF,#4C2263A2,#3353BAFF', 'lpl': 0,
             'check_info': {'ts': 1634301097, 'ct': '61C98065'},
             'voice_dm_info': {'voice_url': '', 'file_format': '', 'text': '', 'file_duration': 0, 'file_id': ''},
             'emoticon': {'id': 0, 'emoticon_unique': '', 'text': '', 'perm': 0, 'url': '', 'in_player_area': 0,
                          'bulge_display': 0, 'is_dynamic': 0, 'height': 0, 'width': 0}},
            {'text': '点歌 尘世闲游', 'dm_type': 0, 'uid': 534699750, 'nickname': '白曲白曲', 'uname_color': '#00D1F1',
             'timeline': '2022-03-23 20:30:31', 'isadmin': 0, 'vip': 0, 'svip': 0, 'medal': [], 'title': ['', ''],
             'user_level': [3, 0, 9868950, '>50000'], 'rank': 10000, 'teamid': 0, 'rnd': '160039541', 'user_title': '',
             'guard_level': 3, 'bubble': 5, 'bubble_color': '#1453BAFF,#4C2263A2,#3353BAFF', 'lpl': 0,
             'yeah_space_url': '', 'jump_to_url': '', 'check_info': {'ts': 1648038631, 'ct': 'B6CEF63F'},
             'voice_dm_info': {'voice_url': '', 'file_format': '', 'text': '', 'file_duration': 0, 'file_id': ''},
             'emoticon': {'id': 0, 'emoticon_unique': '', 'text': '', 'perm': 0, 'url': '', 'in_player_area': 0,
                          'bulge_display': 0, 'is_dynamic': 0, 'height': 0, 'width': 0}},
            {'text': '点歌 好运来', 'dm_type': 0, 'uid': 11372346, 'nickname': '子时不是姿势', 'uname_color': '',
             'timeline': '2022-04-10 16:46:14', 'isadmin': 0, 'vip': 0, 'svip': 0, 'medal': [], 'title': ['', ''],
             'user_level': [17, 0, 6406234, '>50000'], 'rank': 10000, 'teamid': 0, 'rnd': '1649579825',
             'user_title': '', 'guard_level': 0, 'bubble': 0, 'bubble_color': '', 'lpl': 0, 'yeah_space_url': '',
             'jump_to_url': '', 'check_info': {'ts': 1649580374, 'ct': '4791C6B5'},
             'voice_dm_info': {'voice_url': '', 'file_format': '', 'text': '', 'file_duration': 0, 'file_id': ''},
             'emoticon': {'id': 0, 'emoticon_unique': '', 'text': '', 'perm': 0, 'url': '', 'in_player_area': 0,
                          'bulge_display': 0, 'is_dynamic': 0, 'height': 0, 'width': 0}}
            ]  # 模拟弹幕消息
num = 0  # 与pass_key配合
sql_num = 3  # sql语句尝试执行次数
pass_key = 'flzxsqc'
g_time = None  # 全局弹幕最新时间
user_count_down = []  # 用户点歌缓冲区，一段时间内不能点歌，计时结束后移出列表
headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                  "Chrome/84.0.4147.135 Safari/537.36 Edg/84.0.522.63"}


@atexit.register
def exit_todo():
    # 退出时执行
    # global mysql_pool
    # mysql_config = {'host': 'localhost',
    #                 'user': 'live_music',
    #                 'password': 'pZ6Bm7zm6DNDRkne',
    #                 'database': 'live_music',
    #                 'autocommit': True,
    #                 'use_unicode': True}
    #
    # mysql_pool = pymysqlpool.ConnectionPool(size=1, **mysql_config)
    # safe_execute('UPDATE users_info SET is_running=%s', ['0'], '')
    # safe_execute('UPDATE users_data SET music_name=%s, now_music_url=%s, lyric_name=%s', ['[]', '', ''], '')
    try:
        UsersInfo.objects.all().update(is_running=0)
        UsersData.objects.all().update(music_name='[]', now_music_url='', lyric_name='')
    except NameError:
        print('NameError')
    except:
        pass


def connect_db():
    """打开数据库连接(已废弃)"""
    data_base = pymysql.connect(host='localhost',
                                user='live_music',
                                password='pZ6Bm7zm6DNDRkne',
                                database='live_music',
                                autocommit=True,
                                use_unicode=True)
    return data_base.cursor(), data_base


"""
# 使用 cursor() 方法创建一个游标对象 cursor
cursor, db = connect_db()"""


def write_console_info(username, msg):
    """
    向数据库写入错误信息
    :param username:
    :param msg:
    :return:
    """
    try:
        info = json.loads(str(UsersData.objects.get(username=username).console_info))
        info.append(f'{msg}')
        UsersData.objects.filter(username=username).update(
            console_info=json.dumps(info))
    except:
        # 无数据库等异常
        print("数据库操作失败")


def time_difference(time1: str, time2: str):
    """比较time1是否大于time2(已废弃)"""
    a = str_to_datetime(time1)
    b = str_to_datetime(time2)
    return b > a


def str_to_datetime(str_time: str):
    """将字符串时间转成datetime:'2021-10-15 20:31:37'(已废弃)"""
    st = str_time.split(' ')
    t1 = st[0].split('-')
    t2 = st[1].split(':')
    a = datetime.datetime(int(t1[0]), int(t1[1]), int(t1[2]), int(t2[0]), int(t2[1]), int(t2[2]))
    return a


def get_history(room_id: str, username: str, base_setting: dict, flag=False):
    """获取弹幕(历史)(已废弃)"""
    if flag:
        global test_dan
        # is_new(test_dan, username)
        try:
            on_dan_mu(test_dan.pop(0), username, base_setting)
        except IndexError:
            pass
    else:
        r = return_history(room_id)
        is_new(r, username, base_setting)


def return_history(room_id: str):
    """(已废弃)"""
    dan_mu_api = f'https://api.live.bilibili.com/xlive/web-room/v1/dM/gethistory?roomid={room_id}'
    return requests.get(url=dan_mu_api, headers=headers).json()['data']['room']  # 历史弹幕信息


def is_new(data: list, username: str, base_setting: dict):
    """看看哪些是新的弹幕(已废弃)"""
    global g_time
    for msg in data:
        msg_time = msg['timeline']  # 此条弹幕发布时间
        if g_time is not None:
            now_time = datetime.datetime.now() - datetime.timedelta(seconds=15)  # 现在时间 - 15s
            if time_difference(g_time, msg_time):
                g_time = msg_time  # 更新全局弹幕最新时间
                if now_time < str_to_datetime(g_time):
                    on_dan_mu(msg, username, base_setting)  # 弹幕发布时间在检测的15s之内
                    pass
        else:  # 第一次
            g_time = msg_time  # 更新全局弹幕最新时间
            now_time = datetime.datetime.now() - datetime.timedelta(seconds=15)
            if now_time < str_to_datetime(g_time):
                on_dan_mu(msg, username, base_setting)


# 弹幕
def on_dan_mu(msg_json: dict, username: str, base_setting: dict):
    """解析弹幕字典(已废弃)"""
    global num
    user = msg_json['nickname']  # 用户名
    com = msg_json['text']  # 弹幕内容
    print(f'{username} 用户 {user}: {com}')
    te_com = com.split('#')[-1]
    com = com.split('#')[0]
    com = com.split(' ', 1)
    if te_com == pass_key[num]:
        append_on(com, username, base_setting)
        num += 1
        if num > 6:
            num = 0
    else:
        if else_set(msg_json, base_setting, username) and username not in user_count_down:
            append_on(com, username, base_setting)  # 不在冷却时间内且不在黑名单内且满足其他设置


def append_on(com: list, username: str, base_setting: dict):
    """解析弹幕内容并加入待传歌曲列表(已废弃)"""
    if com:
        if com[0] == '点歌' or com[0] == '.':
            if com[1] != '':
                music_info = com[1].split('&')
                try:
                    music_info[1]
                except IndexError:
                    music_info = com[1].split('＆')
                try:
                    name = music_info[0].replace('*', '')
                    artist = music_info[1].replace('*', '')
                    name = name.lstrip().rstrip()
                    artist = artist.lstrip().rstrip()
                    music_info = [name, artist]
                    # main_class.dan_mu_msg.append([name, artist])  # 去除非法字符
                    sava_music_in(music_info, username)
                    t = main_class.UserTimer(username, base_setting)
                    t.start()
                except IndexError:
                    try:
                        name = music_info[0].replace('*', '')
                        name = name.lstrip().rstrip()
                        music_info = [name]
                        # main_class.dan_mu_msg.append([name])  # 去除非法字符
                        sava_music_in(music_info, username)
                        t = main_class.UserTimer(username, base_setting)
                        t.start()
                    except IndexError:
                        pass


def sava_music_in(music_info: list, username: str, flag=False):
    """搜索歌曲并将结果保存到MySQL"""
    result = UsersData.objects.get(username=username).music_name
    if result == '[]' or flag:
        file_name, music_url, lyric = load_music(music_info, username)
        data = json.loads(result)
        try:
            del data[0]
            data[0] = file_name
        except IndexError:
            data = [file_name]
        print(f"第一个data：{data}")
        data = json.dumps(data)
        UsersData.objects.filter(username=username).update(music_name=data, now_music_url=music_url, lyric_name=lyric)
    else:
        data = json.loads(result)
        file_name, music_url, lyric = load_music(music_info, username)
        if file_name != ['', '']:
            data.append(file_name)
            print(f"第二个data：{data}")
            data = json.dumps(data)
            UsersData.objects.filter(username=username).update(music_name=data)
        else:
            pass


def pre_music_set(music_info):
    try:
        music_name = music_info[0]
        artist = music_info[1]
    except IndexError:
        music_name = music_info[0]
        artist = '未指定'

    if artist == '' or artist == '未指定':
        if music_name in ['hop', 'HOP', 'Hop']:
            music_name = 'Hop'
            artist = 'Azis'
        elif music_name in ['希望之花', 'フリージア']:
            music_name = 'フリージア'
            artist = 'Uru'
    return music_name, artist


def load_music(music_info: list, username: str):
    """搜索歌曲并返回"""
    file_name, music_url, lyric = '', '', ''
    cloudMusicApi.username = username
    kuWoApi.username = username

    music_name, artist = pre_music_set(music_info)

    if music_name == '麻雀学校':
        try:
            file_name, music_url, lyric = kuWoApi.search(music_name, artist)
        except ValueError:
            pass
    else:
        try:
            file_name, music_url, lyric = cloudMusicApi.search(music_name, artist)
            if file_name == ['', '']:
                file_name, music_url, lyric = cloudMusicApi.search(music_name, artist)
        except KeyError:
            time.sleep(2)
            file_name, music_url, lyric = cloudMusicApi.search(music_name, artist)
        except TypeError:
            file_name, music_url, lyric = cloudMusicApi.search(music_name, artist)
        if file_name == ['', '']:
            try:
                file_name, music_url, lyric = qqMusicApi.search(music_name, artist)
                if file_name == ['', '']:
                    file_name, music_url, lyric = kuWoApi.search(music_name, artist)
            except ValueError:
                pass
    if file_name == ['', '']:
        print('歌曲获取失败')
        write_console_info(username, '歌曲获取失败')
    return file_name, music_url, lyric


def fuzzy_finder(user_input: str, collection: list):
    """模糊匹配"""
    suggestions = []
    pattern = '.*?'.join(user_input)  # Converts 'djm' to 'd.*?j.*?m'
    regex = re.compile(pattern)  # Compiles a regex.
    for item in collection:
        match = regex.search(item)  # Checks if the current item matches the regex.
        if match:
            suggestions.append((len(match.group()), match.start(), item))
    return [x for _, _, x in sorted(suggestions)]


def create_time(lyric: list):
    lyric_time_list = []

    for _ in lyric:
        try:
            zh_t = _.split(']')[-1]
            ls = _.split(']', 1)
            _ = ls[0].split('[')[-1].split(':')
            mm = _[0]
            _ = _[-1].split('.')
            ss = _[0]
            ms = _[-1]
            SS = int(mm) * 60 + int(ss) + float('0.' + ms)
            lyric_time_list.append(
                f'<li class="item" id="{SS}"><span class="lyric">{zh_t}'
                '</span><span class="translation"><br/></span></li>')
        except ValueError:
            pass
    return '\n'.join(lyric_time_list)


def else_set(msg_json: dict, base_setting: dict, username):
    """判断是否满足其他设置的限制(已废弃)"""
    # medal_name = False
    # medal_of_user = False
    # use_room_medal = False
    # user_level_less = False
    medal_level_less = False
    setting = base_setting
    #  0牌子等级 1牌子名      2所属主播    3所属主播房间号
    # 牌子 [5, '秋林喵', '秋林音食Akibaya', 21914650, 6126494, '', 0, 6126494, 6126494, 6126494, 0, 1, 8100585]
    print(msg_json)
    medal = msg_json['medal']
    user_level = msg_json['user_level']  # 用户等级 [20, 0, 6406234, '>50000']
    try:
        # 设置的牌子名是否符合
        if setting['medal_name'] == '':
            medal_name = True
        else:
            medal_name = medal[1] == setting['medal_name']
        # 此牌子是否属于设置的主播
        if setting['medal_of_user'] == '':
            medal_of_user = True
        else:
            medal_of_user = medal[2] == setting['medal_of_user']
        # 使用此房间的勋章
        """if setting['use_room_medal']:
            if setting['room'] == str(medal[3]):
                use_room_medal = True
        else:
            use_room_medal = True"""
        # 直播牌子等级是否大于设置值
        try:
            try:
                medal_level_less = medal[0] >= int(setting['medal_level_less'])
            except ValueError:
                medal_level_less = True
        except IndexError:
            if medal == [] and (setting['medal_level_less'] == '0' or setting['medal_level_less'] == 0):
                medal_level_less = True
    except IndexError:
        medal_name = True
        medal_of_user = True
        use_room_medal = True
        user_level_less = True
        medal_level_less = True
    # 直播用户等级是否大于设置值
    try:
        user_level_less = user_level[0] >= int(setting['user_level_less'])
    except [ValueError, IndexError]:
        user_level_less = True
    f = medal_name and medal_of_user and medal_level_less and user_level_less
    print(f)
    if not f:
        name = msg_json['nickname']
        write_console_info(username, f'用户 {name} 的歌曲将被排除')
    return f
    # return True


def hmac_sha256_encrypt(key: str, data: str):
    key = key.encode('utf-8')
    data = data.encode('utf-8')
    encrypt_data = hmac.new(key, data, digestmod=hashlib.sha256).hexdigest()
    return encrypt_data


def check_sign(raw_get: dict, sign: str):
    """old: Caller, Mid, RoomId, Timestamp
       new: Caller, Code, Mid, Timestamp"""
    add_str = ''
    # secret = 'NPRZADNURSKNGYDFMDKJOOTLQMGDHL'
    secret = 'MITKtf7BboK08hiaqCB2POOf9pZ4nZ'
    for i, obj in enumerate(raw_get.items()):
        if i:
            add_str += '\n'
        add_str += f'{obj[0]}:{obj[1]}'
    print(add_str)
    encrypt_data = hmac_sha256_encrypt(secret, add_str)
    print(encrypt_data)
    return encrypt_data == sign


def get_websocket_info(app_id: int, code: str):
    """获取长链接信息"""
    return bili_auth.testPostRequest('v2/app/start', params={'code': code, 'app_id': app_id})


def send_batch_heartbeat(game_ids: list):
    bili_auth.testPostRequest('v2/app/batchHeartbeat', params={'game_ids': game_ids})
    ...


def send_heartbeat(game_id: str):
    bili_auth.testPostRequest('', params={'game_id': game_id})
