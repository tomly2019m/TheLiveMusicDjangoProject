# -*- coding: utf-8 -*-
import json

import requests
import time
import hashlib
import hmac
import random
from hashlib import sha256


def testPostRequest(url: str, params: dict):
    """

    使用B站官方接口获取数据

    :params: url: 域名之后的链接
    :params: params: 要post的数据, 需包含app_id
    :return:
    """
    postUrl = f"https://live-open.biliapi.com/{url}"
    # params = '{' + f'"room_id":{room_id}, "app_id":{app_id}' + '}'
    params = json.dumps(params)
    print(params)
    key = "LXQqjVjZRs2hcGHpMjR2bDuA"
    secret = "MITKtf7BboK08hiaqCB2POOf9pZ4nZ"

    md5 = hashlib.md5()
    md5.update(params.encode())
    ts = time.time()
    nonce = random.randint(1, 100000) + time.time()
    md5data = md5.hexdigest()
    headerMap = {
        "x-bili-timestamp": str(int(ts)),
        "x-bili-signature-method": "HMAC-SHA256",
        "x-bili-signature-nonce": str(nonce),
        "x-bili-accesskeyid": key,
        "x-bili-signature-version": "1.0",
        "x-bili-content-md5": md5data,
    }

    headerList = sorted(headerMap)
    headerStr = ''

    for key in headerList:
        headerStr = headerStr + key + ":" + str(headerMap[key]) + "\n"
    headerStr = headerStr.rstrip("\n")

    appsecret = secret.encode()
    data = headerStr.encode()
    signature = hmac.new(appsecret, data, digestmod=sha256).hexdigest()
    headerMap["Authorization"] = signature
    headerMap["Content-Type"] = "application/json"
    headerMap["Accept"] = "application/json"

    r = requests.post(url=postUrl, headers=headerMap, data=params, verify=False)
    status_code = r.status_code
    content = json.loads(r.content.decode())
    print(content)
    print(status_code)
    return {'status_code': status_code, 'content': content}


if __name__ == '__main__':
    testPostRequest('24032356', {'app_id': '1649539569084'})
