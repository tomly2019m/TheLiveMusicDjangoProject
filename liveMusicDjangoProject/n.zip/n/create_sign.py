from utils import hmac_sha256_encrypt

# https://www.live-music.xyz/for-bili?Caller=bilibili&Mid=16956692&RoomId=2047387&Timestamp=1650769899&Sign=e16595caa5c545eef722fe5513d354f35712f94bfb09b98aee040b98efa72b36&plug_env=0
# https://play-live.bilibili.com/plugins-full/1649539569084?Timestamp=1654520332&RoomId=24701480&Mid=29418115&Caller=bilibili&Sign=dbecf3e0a71e5168445a20736724b370c717d425bc0d22339b9e1f8bda6c01ee&Code=BLMNUWXVJWU85&CodeSign=53d1cab7906e5ffc1281fe926b23ace4d70258a3abc648d2365339b4d6a4f74d&plug_env=0
mid = input('mid:')
roomId = input('room id:')
data = f'Caller:bilibili\nMid:{mid}\nRoomId:{roomId}\nTimestamp:1650769899'
sign = hmac_sha256_encrypt('MITKtf7BboK08hiaqCB2POOf9pZ4nZ', data)
print(sign)
a = 'https://www.live-music.xyz/for-bili?' \
    'Caller=bilibili&' \
    f'Mid={mid}&' \
    f'RoomId={roomId}&' \
    'Timestamp=1650769899&' \
    f'Sign={sign}&' \
    'plug_env=0'
b = 'http://127.0.0.1:8000//for-bili?' \
    'Caller=bilibili&' \
    f'Mid={mid}&' \
    f'RoomId={roomId}&' \
    'Timestamp=1650769899&' \
    f'Sign={sign}&' \
    'plug_env=0'
print(a)
s = 'djfie＆dcfg'
print(s.split('&'))
